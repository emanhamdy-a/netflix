    <div class='ht-options col-12'id='hedr'style='position:fixed;z-index:999;'><!---->
       <div class='container'>
               <div class='row '>
                   <div class='ht-social col-7'>
                   <div class='ht-social'>
                           <a class='' href='./index.php' id='logo0' style='color:white;font-size:22px;font-family:arial rounded mt;;'>get<strong id='logo1' style='color:red;'>M</strong>ovie</a>
                           <a class='ar hdr' href='#'style='display:none;'><i class='fa fa-search'></i> </a>
                           <a class='ar hdr' href='./TVshows.php'style=''>مسلسلات</i></a>
                           <a class='ar hdr' href='./Movies.php' style=''>افلام</i></a>
                           <a class='ar hdr' href='#' style='display:none;'><i class='fa fa-line-chart'></i></a>
                       </div>
                   </div>
                   <div class='col-5 text-right pt-2'>
                       <div class='ht-widget'>
                           <ul>
                               <li style='cursor:pointer;'>
                                   <a class='m-0 mr-1' style='color:white;' href='search.php'> 
                                   <i style='font-size:16px;' class='fa fa-search'></i> </a>
                                   <a class='m-0 pr-2' style='color:white;' href='profile.php'> 
                                   <i style='font-size:16px;' class='fa fa-user-circle'></i> <a>
                                   <a class='m-0 pr-2' style='color:white;' href='logout.php'> 
                                   <i style='font-size:16px;' class='fa fa-sign-out'></i> <a>
                               </li>
                           </ul>
                       </div>
                   </div>
               </div>
           </div>
       </div>
    </div>