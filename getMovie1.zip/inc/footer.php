    <!-- Footer Section Begin -->
        <footer class='footer-section'>
            <div class='container'>
                <div class='row'>
                    <div class='col-lg-4'>
                        <div class='footer-about col-12 text-left'>
                            <div class='text-left p-4'>
                                <a class='p-0 pb-3' href='./index.php' id='logo0' style='color:white;font-size:28px;font-family:arial rounded mt;'>get<strong id='logo1' style='color:red;'>M</strong>ovie</a>
                            </div>
                            <div class='fa-social'>
                                <a href='#'><i class='fa fa-facebook'></i></a>
                                <a href='#'><i class='fa fa-twitter'></i></a>
                                <a href='#'><i class='fa fa-youtube-play'></i></a>
                                <a href='#'><i class='fa fa-instagram'></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='copyright-area'>
                    <div class='row'>
                        <div class='col-lg-6'>
                            <div class='ca-text'><p>Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0.
                        </div>
                        <div class='col-lg-6'>

                        </div>
                    </div>
                </div>
            </div>
        </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src='js/jquery-3.3.1.min.js'></script>
    <script src='js/bootstrap.min.js'></script>
    <script src='js/jquery.magnific-popup.min.js'></script>
    <script src='js/circle-progress.min.js'></script>
    <script src='js/jquery.barfiller.js'></script>
    <script src='js/jquery.slicknav.js'></script>
    <script src='js/owl.carousel.min.js'></script>
    <script src='js/main.js'></script>
    <script src='js/getMovie.js'></script>
</body>
    <script>
    </script>
</html>